﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Podaj wysokość: ");
        int h = Convert.ToInt32(Console.ReadLine());
        while (h > 0)
        {
            int g = 0;
            while (g < h)
            {
                Console.Write("*");
                g++;
            }
            Console.WriteLine();
            h--;
        }
    }
}
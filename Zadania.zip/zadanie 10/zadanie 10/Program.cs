﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        while (true)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            if (a > 0)
            {
                Console.WriteLine(a);
            }
            if (a < 0)
            {
                Console.WriteLine("Błąd spóbuj jeszcze raz!");
                a = Convert.ToInt32(Console.ReadLine());
            }

        }
    }
}
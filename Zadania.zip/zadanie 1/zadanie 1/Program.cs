﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("wpisz liczbę: ");
        int z = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine();
        int a = 1;

        while(z <= 0)
        {
            Console.WriteLine("BŁĄD! a musi być większe od 0");
            z = Convert.ToInt32(Console.ReadLine());
        }

        while (z >= a)
        {
            if(a % 2 == 1)
            {
                Console.WriteLine(a);
               
            }
            a++;
        }
    }
}
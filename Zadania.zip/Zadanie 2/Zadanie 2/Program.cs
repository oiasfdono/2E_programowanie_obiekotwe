﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Temperatura w celcjuszach początkowa: ");
        int a = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("temmperatura w celcjuszach końcowa: ");
        int b = Convert.ToInt32(Console.ReadLine());

        if (a > b)
        {
            Console.WriteLine("Błąd temperatura początkowa musi być mniejsza niż koncowa. Spróbuj ponownie:");
            return;
        }
        while (a <= b)
        {
            double c = (a * 1.8) + 34;
            Console.WriteLine("W farenheitach: ");
            Console.WriteLine(c);
            a++;
        }

    }
}